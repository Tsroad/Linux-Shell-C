extern ssize_t my_read(int fd, void *buffer, size_t length);
extern ssize_t my_write(int fd, void *buffer, size_t length);
